#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9da233b8(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_7e4b6e07() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_2e9311a0(inout vec4 vertex) {
    f_9da233b8(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_7e4b6e07();
    }
        finalize();
}



void f_6f25510b() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_5d7eb336() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_606ea509(inout vec4 vertex) {
    f_9da233b8(vertex);
    f_6f25510b();
    finalize();
}

void f_eaf1095f(inout vec4 vertex) {
    f_9da233b8(vertex);
    f_7e4b6e07();
    f_5d7eb336();
    finalize();
}

void f_3cd53d82(inout vec4 vertex) {
    f_9da233b8(vertex);
    f_5d7eb336();
    f_6f25510b();
    finalize();
}

void f_5302566f(inout vec4 vertex) {
    f_7e4b6e07();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9da233b8(vertex);
    finalize();
}

void f_2bec85d9(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6f25510b();
    f_9da233b8(vertex);
    finalize();
}

void f_c4a2f9c0(inout vec4 vertex, float speed) {
    f_9da233b8(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_cfd47c7a(inout vec4 vertex) {
    f_9da233b8(vertex);
    f_7e4b6e07();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_2e9311a0(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_7e4b6e07();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9da233b8(vertex);
            f_7e4b6e07();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_eaf1095f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_eaf1095f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_5302566f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_5302566f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c4a2f9c0(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_cfd47c7a(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_606ea509(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_eaf1095f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_3cd53d82(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_5302566f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_2bec85d9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c4a2f9c0(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_606ea509(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_eaf1095f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_3cd53d82(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_5302566f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_2bec85d9(vertex);
        return;
    }
    

    
    f_9da233b8(vertex);
    f_7e4b6e07();
    finalize();
}