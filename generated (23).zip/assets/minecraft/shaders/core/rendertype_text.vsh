#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9e733a23(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e30e0a58() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_5ac57f79(inout vec4 vertex) {
    f_9e733a23(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e30e0a58();
    }
    finalize();
}



void f_da7a747a() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_a8f2b867() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_8d35288a(inout vec4 vertex) {
    f_9e733a23(vertex);
    f_da7a747a();
    finalize();
}

void f_66aa3f5a(inout vec4 vertex) {
    f_9e733a23(vertex);
    f_e30e0a58();
    f_a8f2b867();
    finalize();
}

void f_10173ba3(inout vec4 vertex) {
    f_9e733a23(vertex);
    f_a8f2b867();
    f_da7a747a();
    finalize();
}

void f_f1e9bc5c(inout vec4 vertex) {
    f_e30e0a58();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9e733a23(vertex);
    finalize();
}

void f_b6825f27(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_da7a747a();
    f_9e733a23(vertex);
    finalize();
}

void f_c2e156f3(inout vec4 vertex, float speed) {
    f_9e733a23(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_8c3f4021(inout vec4 vertex) {
    f_9e733a23(vertex);
    f_e30e0a58();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_5ac57f79(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e30e0a58();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9e733a23(vertex);
            f_e30e0a58();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_66aa3f5a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_66aa3f5a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_f1e9bc5c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_f1e9bc5c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c2e156f3(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_8c3f4021(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_8d35288a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_66aa3f5a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_10173ba3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_f1e9bc5c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_b6825f27(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c2e156f3(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_8d35288a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_66aa3f5a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_10173ba3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_f1e9bc5c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_b6825f27(vertex);
        return;
    }
    

    
    f_9e733a23(vertex);
    f_e30e0a58();
    finalize();
}