#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_b790b095(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_c4add037() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_c9b1319f(inout vec4 vertex) {
    f_b790b095(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_c4add037();
    }
        finalize();
}



void f_1324d7fe() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_6f5a0f2f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_43e9920f(inout vec4 vertex) {
    f_b790b095(vertex);
    f_1324d7fe();
    finalize();
}

void f_b615d614(inout vec4 vertex) {
    f_b790b095(vertex);
    f_c4add037();
    f_6f5a0f2f();
    finalize();
}

void f_9349bc6c(inout vec4 vertex) {
    f_b790b095(vertex);
    f_6f5a0f2f();
    f_1324d7fe();
    finalize();
}

void f_42f6de74(inout vec4 vertex) {
    f_c4add037();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b790b095(vertex);
    finalize();
}

void f_913907ef(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_1324d7fe();
    f_b790b095(vertex);
    finalize();
}

void f_840323de(inout vec4 vertex, float speed) {
    f_b790b095(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_dac69a4d(inout vec4 vertex) {
    f_b790b095(vertex);
    f_c4add037();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_c9b1319f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_c4add037();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_b790b095(vertex);
            f_c4add037();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b615d614(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b615d614(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_42f6de74(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_42f6de74(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_840323de(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_dac69a4d(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_43e9920f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b615d614(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_9349bc6c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_42f6de74(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_913907ef(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_840323de(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_43e9920f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b615d614(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_9349bc6c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_42f6de74(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_913907ef(vertex);
        return;
    }
    

    
    f_b790b095(vertex);
    f_c4add037();
    finalize();
}